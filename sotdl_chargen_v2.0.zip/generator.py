# -*- coding: utf-8 -*-
from load_json import Import


character_file = Import()
file_extension = ".json"


class Generator():
    @classmethod
    def char_names(self, char_ancestry, char_info):
        attributes_list = character_file.json_file(
            ".\\ancestries" + "\\" + char_ancestry + "\\" + char_ancestry +
            "_" + char_info + file_extension
            )
        return(attributes_list)
